/**
 * JavaScript API для работы с календарем Android
 */
(function() {
  // Объект для колбэков статуса разрешений
  const permissionCallbacks = {
      granted: [],
      denied: []
  };
  
  // Глобальные обработчики события изменения статуса разрешений
  window.onCalendarPermissionGranted = function() {
      permissionCallbacks.granted.forEach(callback => callback());
      permissionCallbacks.granted = [];
  };
  
  window.onCalendarPermissionDenied = function() {
      permissionCallbacks.denied.forEach(callback => callback());
      permissionCallbacks.denied = [];
  };
  
  // API для работы с календарем
  window.CalendarAPI = {
      /**
       * Проверяет наличие разрешений на работу с календарем
       * @returns {Promise<boolean>} Промис, который разрешается в true, если разрешения есть, иначе в false
       */
      checkCalendarPermissions: function() {
          return new Promise((resolve, reject) => {
              try {
                  const result = JSON.parse(window.CalendarBridge.hasCalendarPermissions());
                  if (result.success) {
                      resolve(result.hasPermissions);
                  } else {
                      reject(new Error(result.error || 'Ошибка при проверке разрешений'));
                  }
              } catch (error) {
                  reject(error);
              }
          });
      },
      
      /**
       * Запрашивает разрешения на работу с календарем, если их нет
       * @returns {Promise<boolean>} Промис, который разрешается в true, если разрешения получены
       */
      requestCalendarPermissions: function() {
          return new Promise((resolve, reject) => {
              this.checkCalendarPermissions().then(hasPermissions => {
                  if (hasPermissions) {
                      // Разрешения уже есть
                      resolve(true);
                  } else {
                      // Регистрируем коллбэки и вызываем Activity для запроса разрешений
                      permissionCallbacks.granted.push(() => resolve(true));
                      permissionCallbacks.denied.push(() => resolve(false));
                      
                      // Вызываем метод для запроса разрешений через Android Bridge
                      try {
                          // Предполагаем, что у нас есть мост для запроса разрешений
                          // Если этого метода нет в мосте, его нужно добавить
                          if (window.CalendarBridge && window.CalendarBridge.requestCalendarPermissions) {
                              window.CalendarBridge.requestCalendarPermissions();
                          } else {
                              // Если метода нет, то считаем, что разрешения мы не получим
                              resolve(false);
                          }
                      } catch (error) {
                          reject(error);
                      }
                  }
              }).catch(reject);
          });
      },
      
      /**
       * Добавляет событие в календарь
       * @param {Object} event Объект события
       * @returns {Promise<Object>} Промис с результатом операции
       */
      addEventToCalendar: function(event) {
          return new Promise((resolve, reject) => {
              try {
                  const result = JSON.parse(window.CalendarBridge.addEventToCalendar(JSON.stringify(event)));
                  if (result.success) {
                      resolve(result);
                  } else {
                      reject(new Error(result.error || 'Ошибка при добавлении события'));
                  }
              } catch (error) {
                  reject(error);
              }
          });
      },
      
      /**
       * Удаляет событие из календаря
       * @param {string} eventId ID события
       * @returns {Promise<Object>} Промис с результатом операции
       */
      deleteEvent: function(eventId) {
          return new Promise((resolve, reject) => {
              try {
                  const result = JSON.parse(window.CalendarBridge.deleteEvent(eventId));
                  if (result.success) {
                      resolve(result);
                  } else {
                      reject(new Error(result.error || 'Ошибка при удалении события'));
                  }
              } catch (error) {
                  reject(error);
              }
          });
      }
  };
})();

/**
* Пример использования API:

// Проверка разрешений
CalendarAPI.checkCalendarPermissions()
  .then(hasPermissions => {
      console.log("Есть разрешения на календарь:", hasPermissions);
      
      if (!hasPermissions) {
          // Запрашиваем разрешения, если их нет
          return CalendarAPI.requestCalendarPermissions();
      }
      return hasPermissions;
  })
  .then(granted => {
      if (granted) {
          console.log("Разрешения получены, можно работать с календарем");
          
          // Пример добавления события
          const event = {
              id: "event_123",
              title: "Важная встреча",
              description: "Обсуждение проекта",
              date: "2023-08-15T14:00:00",
              url: "https://example.com/meeting",
              alarmDates: ["2023-08-15T13:30:00", "2023-08-14T18:00:00"]
          };
          
          return CalendarAPI.addEventToCalendar(event);
      } else {
          console.log("Разрешения не получены, работа с календарем невозможна");
      }
  })
  .then(result => {
      if (result && result.success) {
          console.log("Событие добавлено:", result);
          
          // Пример удаления события
          // return CalendarAPI.deleteEvent("event_123");
      }
  })
  .catch(error => {
      console.error("Ошибка:", error);
  });
*/