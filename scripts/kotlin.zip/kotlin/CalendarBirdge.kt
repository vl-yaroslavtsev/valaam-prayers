package com.example.app

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class CalendarBridge(private val context: Context) {
    
    companion object {
        private const val TAG = "CalendarBridge"
        private const val DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss"
        private val CALENDAR_PERMISSIONS = arrayOf(
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR
        )
    }
    
    private val dateFormat = SimpleDateFormat(DATE_FORMAT, Locale.getDefault()).apply {
        timeZone = TimeZone.getDefault()
    }
    
    @JavascriptInterface
    fun hasCalendarPermissions(): String {
        try {
            val hasPermissions = CALENDAR_PERMISSIONS.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
            
            return JSONObject().apply {
                put("success", true)
                put("hasPermissions", hasPermissions)
                put("message", if (hasPermissions) 
                    "Разрешения на работу с календарем получены" 
                    else "Отсутствуют разрешения на работу с календарем")
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка при проверке разрешений: ${e.message}", e)
            return createErrorResponse("Ошибка при проверке разрешений: ${e.message}")
        }
    }
    
    @JavascriptInterface
    fun requestCalendarPermissions(): String {
        try {
            // Проверяем, имеем ли мы разрешения
            val hasPermissions = CALENDAR_PERMISSIONS.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
            
            if (hasPermissions) {
                // Если разрешения уже есть, возвращаем успешный результат
                return JSONObject().apply {
                    put("success", true)
                    put("hasPermissions", true)
                    put("message", "Разрешения на работу с календарем уже получены")
                }.toString()
            } else {
                // Если активность не является AppCompatActivity, возвращаем ошибку
                if (context !is AppCompatActivity) {
                    return createErrorResponse("Контекст не является AppCompatActivity, невозможно запросить разрешения")
                }
                
                // Запрашиваем разрешения
                ActivityCompat.requestPermissions(
                    context as AppCompatActivity,
                    CALENDAR_PERMISSIONS,
                    1001 // Используем тот же код, что и в MainActivity
                )
                
                // Возвращаем информацию о том, что запрос был отправлен
                return JSONObject().apply {
                    put("success", true)
                    put("requested", true)
                    put("message", "Запрос на разрешения отправлен, ожидайте ответа пользователя")
                }.toString()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка при запросе разрешений: ${e.message}", e)
            return createErrorResponse("Ошибка при запросе разрешений: ${e.message}")
        }
    }
    
    @JavascriptInterface
    fun addEventToCalendar(eventJson: String): String {
        // Сначала проверяем наличие разрешений
        val permissionsResult = JSONObject(hasCalendarPermissions())
        if (permissionsResult.getBoolean("success") && !permissionsResult.getBoolean("hasPermissions")) {
            return createErrorResponse("Отсутствуют необходимые разрешения для работы с календарем")
        }
        
        try {
            val event = JSONObject(eventJson)
            val id = event.getString("id")
            val title = event.getString("title")
            val description = event.getString("description")
            val dateStr = event.getString("date")
            val url = event.getString("url")
            
            // Парсинг основной даты события
            val eventDate = dateFormat.parse(dateStr)
            val calendarTime = Calendar.getInstance()
            eventDate?.let { calendarTime.time = it }
            
            val startMillis = calendarTime.timeInMillis
            // Устанавливаем продолжительность события в 1 час
            val endMillis = startMillis + 60 * 60 * 1000
            
            // Получаем ID календаря по умолчанию
            val calendarId = getDefaultCalendarId(context.contentResolver)
            if (calendarId == -1L) {
                return createErrorResponse("Не удалось найти календарь по умолчанию")
            }
            
            // Создаем событие
            val eventValues = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calendarId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, endMillis)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 1)
                
                // Добавляем URL как описание или хранение данных
                put(CalendarContract.Events.CUSTOM_APP_URI, url)
                // Сохраняем наш ID как свойство события для возможности его удаления позже
                put(CalendarContract.Events.CUSTOM_APP_PACKAGE, id)
            }
            
            // Вставляем событие в календарь
            val eventUri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, eventValues)
            val eventID = eventUri?.let { ContentUris.parseId(it) } ?: -1
            
            if (eventID == -1L) {
                return createErrorResponse("Не удалось создать событие")
            }
            
            // Добавляем напоминания, если они указаны
            if (event.has("alarmDates") && !event.isNull("alarmDates")) {
                val alarmDates = event.getJSONArray("alarmDates")
                for (i in 0 until alarmDates.length()) {
                    val alarmDateStr = alarmDates.getString(i)
                    addReminder(eventID, alarmDateStr, startMillis)
                }
            } else {
                // Добавляем стандартное напоминание за 30 минут до события
                val reminderValues = ContentValues().apply {
                    put(CalendarContract.Reminders.EVENT_ID, eventID)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                    put(CalendarContract.Reminders.MINUTES, 30)
                }
                context.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminderValues)
            }
            
            // Возвращаем успешный результат
            return JSONObject().apply {
                put("success", true)
                put("eventId", eventID.toString())
                put("message", "Событие успешно добавлено")
            }.toString()
            
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка при добавлении события: ${e.message}", e)
            return createErrorResponse("Ошибка при добавлении события: ${e.message}")
        }
    }
    
    @JavascriptInterface
    fun deleteEvent(eventId: String): String {
        // Сначала проверяем наличие разрешений
        val permissionsResult = JSONObject(hasCalendarPermissions())
        if (permissionsResult.getBoolean("success") && !permissionsResult.getBoolean("hasPermissions")) {
            return createErrorResponse("Отсутствуют необходимые разрешения для работы с календарем")
        }
        
        try {
            // Ищем событие по нашему ID (хранится в CUSTOM_APP_PACKAGE)
            val selection = "${CalendarContract.Events.CUSTOM_APP_PACKAGE} = ?"
            val selectionArgs = arrayOf(eventId)
            
            val cursor = context.contentResolver.query(
                CalendarContract.Events.CONTENT_URI,
                arrayOf(CalendarContract.Events._ID),
                selection,
                selectionArgs,
                null
            )
            
            if (cursor?.moveToFirst() == true) {
                val systemEventId = cursor.getLong(0)
                cursor.close()
                
                // Удаляем событие
                val deleteUri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, systemEventId)
                val rowsDeleted = context.contentResolver.delete(deleteUri, null, null)
                
                return if (rowsDeleted > 0) {
                    JSONObject().apply {
                        put("success", true)
                        put("message", "Событие успешно удалено")
                    }.toString()
                } else {
                    createErrorResponse("Не удалось удалить событие")
                }
            } else {
                cursor?.close()
                return createErrorResponse("Событие не найдено")
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка при удалении события: ${e.message}", e)
            return createErrorResponse("Ошибка при удалении события: ${e.message}")
        }
    }
    
    private fun addReminder(eventID: Long, alarmDateStr: String, eventTimeMillis: Long) {
        try {
            val alarmDate = dateFormat.parse(alarmDateStr)
            if (alarmDate != null) {
                val alarmTime = Calendar.getInstance()
                alarmTime.time = alarmDate
                val alarmTimeMillis = alarmTime.timeInMillis
                
                // Вычисляем разницу в минутах между временем события и временем напоминания
                val diffMinutes = (eventTimeMillis - alarmTimeMillis) / (60 * 1000)
                
                val reminderValues = ContentValues().apply {
                    put(CalendarContract.Reminders.EVENT_ID, eventID)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                    put(CalendarContract.Reminders.MINUTES, diffMinutes)
                }
                context.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminderValues)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка при добавлении напоминания: ${e.message}", e)
        }
    }
    
    private fun getDefaultCalendarId(contentResolver: ContentResolver): Long {
        var calendarId = -1L
        
        val projection = arrayOf(CalendarContract.Calendars._ID)
        val selection = "${CalendarContract.Calendars.VISIBLE} = 1 AND ${CalendarContract.Calendars.IS_PRIMARY} = 1"
        
        contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            selection,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                calendarId = cursor.getLong(0)
            } else {
                // Если не найден основной календарь, просто берем первый видимый
                contentResolver.query(
                    CalendarContract.Calendars.CONTENT_URI,
                    projection,
                    "${CalendarContract.Calendars.VISIBLE} = 1",
                    null,
                    null
                )?.use { cursor2 ->
                    if (cursor2.moveToFirst()) {
                        calendarId = cursor2.getLong(0)
                    }
                }
            }
        }
        
        return calendarId
    }
    
    private fun createErrorResponse(errorMessage: String): String {
        return JSONObject().apply {
            put("success", false)
            put("error", errorMessage)
        }.toString()
    }
}

/*
Пример использования метода hasCalendarPermissions в JavaScript:

// Проверка разрешений
const permissionResult = JSON.parse(window.CalendarBridge.hasCalendarPermissions());
if (permissionResult.success && permissionResult.hasPermissions) {
    // Разрешения получены, можно работать с календарем
} else {
    // Нужно запросить разрешения
}

// Проверка перед добавлением события
const addEvent = () => {
    if (checkPermissions()) {
        // Код добавления события
        const event = {
            id: "event_123",
            title: "Встреча",
            description: "Важная встреча",
            date: "2023-06-15T14:00:00",
            url: "https://example.com"
        };
        
        const result = window.CalendarBridge.addEventToCalendar(JSON.stringify(event));
        console.log(JSON.parse(result));
    }
};
*/
